angular.module('app.controllers', [])
  
.controller('mySkyCtrl', function($scope) {

})
    